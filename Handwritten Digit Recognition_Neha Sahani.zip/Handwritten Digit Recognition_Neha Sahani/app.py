# digit_recognizer_app.py

import streamlit as st
import numpy as np
import tensorflow as tf
from PIL import Image, ImageOps

# Load the trained MNIST model
model = tf.keras.models.load_model('mnist_model.h5')

# UI title
st.set_page_config(page_title="Digit Recognizer", page_icon="✍️")
st.title("🧠 Handwritten Digit Recognition")
st.write("Upload an image of a digit (0-9) and let the model predict it!")

# Upload image
uploaded_file = st.file_uploader("Upload a handwritten digit image", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert("L")  # Convert to grayscale
    st.image(image, caption='Uploaded Image', use_column_width=True)

    # Resize & preprocess image
    image = ImageOps.invert(image)  # Invert: background white, digit black
    image = image.resize((28, 28))
    img_array = np.array(image).astype('float32') / 255.0
    img_array = img_array.reshape(1, 28, 28, 1)

    # Predict
    prediction = model.predict(img_array)
    predicted_digit = np.argmax(prediction)
    confidence = np.max(prediction)

    st.markdown(f"### ✅ Predicted Digit: **{predicted_digit}**")
    st.markdown(f"### 🔍 Confidence: **{confidence*100:.2f}%**")

    # Display probability bar chart
    st.bar_chart(prediction[0])

else:
    st.info("Please upload an image to see prediction.")
